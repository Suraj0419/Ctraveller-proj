class DataCollection {
    get routeDropdown() {
     return  $('//input[@id="routeCard"]');
   }
 
   submitButton() {
     return $("//button[text()='Submit']");
   }
   checkbox() {
    return $("//input[@id='IsValid']");
  }

   async getLength() {
    return await $("#Length");
  }

  async getBreadth() {
    return await $("#Breadth");
  }

  async getComments() {
    return await $("#Comments");
  }

  async getHeight() {
    return await $("#Height");
  }

  async getWeight() {
    return await $("#Weight");
  }

  async getDivAccordion(){
    return await $("//div[text()='Additional fields']");
  }

  async enterComments(comments:string){
    await (await this.getDivAccordion()).click();
    await (await this.getComments()).setValue(comments);
  }
  
  async enterHeight(height:string){)
    await (await this.getHeight()).clearValue();
    await (await this.getHeight()).setValue(height);
  }
  async enterLength(length:string){
    await (await this.getHeight()).clearValue();
    await (await this.getHeight()).setValue(length);
  }
  async enterWeight(weight:string){
    await (await this.getWeight()).clearValue();
    await (await this.getWeight()).setValue(weight);
  }
  async enterBreadth(breadth:string){
    await (await this.getWeight()).clearValue();
    await (await this.getWeight()).setValue(breadth);
  }
   async selectRouteDropdown(routeCard: string) {
    await (await this.routeDropdown).click();
    await (await this.routeDropdown).setValue(routeCard);
     const suggestionOption = await $(`//*[text()="${routeCard}"]`);
     await suggestionOption.waitForDisplayed({timeout:2000})
     await suggestionOption.waitForClickable({timeout:2000})
     console.log(suggestionOption)
     await suggestionOption.click();
   }


   async clickSubmitButton() {
     await this.submitButton().click();
   }

   async clickCheckbox() {
    await this.checkbox().click();
  }


   async getAlert() {
    const messageXPath = "//*[contains(text(),'Data Collected successfully')]";
    return await $(messageXPath);
  }

    get getProductText(){
     return  $('//h4[text()="Product:"]');
   }
 }
 export default new DataCollection();
 