class DisassociateTransaction {
    get routeDropdown() {
     return  $('//input[@id="Routecard"]');
   }
 
   submitButton() {
     return $('[type="submit"]');
   }
 
   async selectRouteDropdown(routeCard: string) {
    await (await this.routeDropdown).click();
    await (await this.routeDropdown).setValue(routeCard);
     const suggestionOption = await $(`//*[text()="${routeCard}"]`);
     await suggestionOption.waitForDisplayed({timeout:2000})
     await suggestionOption.waitForClickable({timeout:2000})
     console.log(suggestionOption)
     await suggestionOption.click();
   }


   async clickSubmitButton() {
     await this.submitButton().click();
   }


   async getAlert() {
    const messageXPath = "//*[contains(text(),'Disassociated successfully')]";
    return await $(messageXPath);
  }
 
  async getCheckbox(routeCard:string) {
    console.log(routeCard)
    const routeCheckBox = `//div[contains(@class, 'MuiDataGrid-cell') and text()='${routeCard}']`
   // console.log(routeCheckBox)
      const check= await $(routeCheckBox)
      console.log(check);
      await check.waitForDisplayed({timeout:5000})
     await check.waitForClickable({timeout:5000});
       (await (await check.parentElement()).previousElement()).click();
  }

  async getHeaderCheckbox() {
    const divElement = await $('//div[@class="MuiDataGrid-columnHeaderTitleContainerContent"]');
    console.log(divElement)
   //const check= await divElement.$('input[type="checkbox"]');
      await divElement.waitForDisplayed({timeout:5000})
     await divElement.waitForClickable({timeout:5000});
      await divElement.click();
  }
   
 
    get getProductText(){
     return  $('//h4[text()="Product:"]');
   }
 }
 export default new DisassociateTransaction();
 