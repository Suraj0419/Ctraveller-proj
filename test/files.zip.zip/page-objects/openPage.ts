class OpenTransaction {
    get routeDropdown() {
     return  $('//input[@id="routeCard"]');
   }
 
   submitButton() {
     return $('[type="submit"]');
   }
 
   async selectRouteDropdown(routeCard: string) {
    await (await this.routeDropdown).click();
    await (await this.routeDropdown).setValue(routeCard);
     const suggestionOption = await $(`//*[text()="${routeCard}"]`);
     await suggestionOption.waitForDisplayed({timeout:2000})
     await suggestionOption.waitForClickable({timeout:2000})
     console.log(suggestionOption)
     await suggestionOption.click();
   }


   async clickSubmitButton() {
     await this.submitButton().click();
   }


   async getAlert() {
    const messageXPath = "//*[contains(text(), 'Opened successfully')]";
    return await $(messageXPath);
  }
 
   
 
    get getProductText(){
     return  $('//h4[text()="Product:"]');
   }
 }
 export default new OpenTransaction();
 