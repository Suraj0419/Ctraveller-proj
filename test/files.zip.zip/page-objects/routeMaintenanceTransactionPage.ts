class RouteMaintenanceTransactionPage {
  getSuccessButton() {
    return $(".swal2-confirm .swal2-styled");
  }
  get routeDropdown() {
    return $('//input[@id="routeCard"]');
  }
  async selectRouteDropdown(routeCard: string) {
    await (await this.routeDropdown).click();
    await (await this.routeDropdown).setValue(routeCard);
    const suggestionOption = await $(`//*[text()="${routeCard}"]`);
    await suggestionOption.waitForDisplayed({ timeout: 5000 });
    await suggestionOption.waitForClickable({ timeout: 5000 });
    console.log(suggestionOption);
    await suggestionOption.click();
  }
  get startReasonDropdown() {
    return $("#StartReasonName");
  }

  async ChooseDateButton() {
   // console.log( await $$('//button[contains(@aria-label, "Choose date")]'))
    return await $$('//button[contains(@aria-label, "Choose date")]')[0];
  }

   async ChooseDateExpButton() {
   // console.log(await $$('//button[contains(@aria-label, "Choose date")]').length)
    return await $$('//button[contains(@aria-label, "Choose date")]')[1];
  }


  getDepartmentDropdown() {
    return $("#DepName");
  }

  getLevelDropDown() {
    return $("#Levelname");
  }
  get productionOrderDropdown() {
    return $("#ProductionOrder");
  }
  get productDropdown() {
    return $("#Product");
  }
  get customerDropdown() {
    return $("#Customer");
  }
  get factoryDropdown() {
    return $("#Factory");
  }
  get processFlowDropdown() {
    return $("#Processflow");
  }
  get locationDropdown() {
    return $("#Location");
  }
  get uomDropdown() {
    return $("#UOM");
  }
  get supplierItemDropdown() {
    return $("#SupplierItem");
  }
  get dueDateInput() {
    //return $('#:rr:');
    return $$('[placeholder="DD/MM/YYYY hh:mm:ss"]')[0];
  }
  get expirationDateInput() {
    return $$('[placeholder="DD/MM/YYYY hh:mm:ss"]')[1];
  }
  get submitButton() {
    return $('[type="submit"]');
  }
  get resetButton() {
    return $('[type="reset"]');
  }

  async clickSubmitButton() {
    await this.submitButton.click();
  }

  async clickResetButton() {
    await this.resetButton.click();
  }

  async enterDepartment(department: string) {
    (await this.getDepartmentDropdown()).click();
    // (await this.getDepartmentDropdown()).selectByVisibleText(department);
    const suggestionOption = await browser.$(`//*[text()="${department}"]`);
    await suggestionOption.click();
    //(await this.getDepartmentDropdown()).setValue(department)
  }

  async enterLevel(level: string) {
    (await this.getLevelDropDown()).click();
    const suggestionOption = await browser.$(`//*[text()="${level}"]`);
    await suggestionOption.click();
  }

  async selectStartReason(reason: string) {
    (await this.startReasonDropdown).click();
    const suggestionOption = await browser.$(`//*[text()="${reason}"]`);
    await suggestionOption.click();
  }

  async selectProductionOrder(productionOrder: string) {
    await this.productionOrderDropdown.click();
    const suggestionOption = await browser.$(
      `//*[text()="${productionOrder}"]`
    );
    await suggestionOption.click();
  }

  async selectProductDropdown(product) {
    (await this.productDropdown).click();
    const suggestionOption = await browser.$(`//*[text()="${product}"]`);
    await suggestionOption.click();
  }

  async selectFactoryDropdown(factory: string) {
    await (await this.factoryDropdown).click();
    const suggestionOption = await browser.$(`//*[text()="${factory}"]`);
    await suggestionOption.click();
  }

  async selectUOMDropdown(uom: string) {
    await (await this.uomDropdown).click();
    const suggestionOption = await browser.$(`//*[text()="${uom}"]`);
    await suggestionOption.click();
  }

  convertDateToTimeStamp(dateString: string) {
    const [datePart, timePart] = dateString.split(" ");
    const [day, month, year] = datePart.split("/");
    const [hours, minutes, seconds] = timePart.split(":");
    const dateObject = new Date(
      Number(year),
      Number(month) - 1,
      Number(day),
      Number(hours),
      Number(minutes),
      Number(seconds)
    );
    return dateObject.getTime();
  }
  async enterDueDate(dueDate: string) {
    console.log('due date called');
    await(await this.ChooseDateButton()).click();
    console.log(dueDate)
    const dataStamp = this.convertDateToTimeStamp(dueDate);
    const timestampString = dataStamp.toString();

    const dueDateCal = $(
      `//button[@role='gridcell' and @data-timestamp='${timestampString}']`
    );
    await dueDateCal.click();
   await (await this.CalendarOkButton()).click();
  }
  async enterExpirationDate(expirationDate: string) {
    console.log('exp date called');
    await(await this.ChooseDateExpButton()).click();
    console.log(expirationDate)
    const dataStamp = this.convertDateToTimeStamp(expirationDate);
    const timestampString = dataStamp.toString();
    const expDateCal = $(
      `//button[@role='gridcell' and @data-timestamp='${timestampString}']`
    );
    await expDateCal.click();
    await(await this.CalendarOkButton()).click();
    //  (await this.expirationDateInput).setValue(expirationDate);
  }

  async getAlert() {
    const messageXPath = "//*[contains(text(), 'RouteCard Maintenance successful')]";
    return await $(messageXPath);
  }

  async okButton() {
    return $('//button[text()="Ok"]');
  }

  async CalendarOkButton() {
    return $('//button[text()="OK"]');
  }

  get getProductText(){
    return  $('//h4[text()="Product:"]');
  }


  // Implement methods for other fields as needed
}

export default new RouteMaintenanceTransactionPage();
