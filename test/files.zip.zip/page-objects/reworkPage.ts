class Rework {
    get routeDropdown() {
     return  $('//input[@id="Routecard"]');
   }
 
  get EquipmentDropDown() {
     return $("#Equipment");
   }
 
  get ToReworkStep() {
     return  $("#StepName");
   }
   get ReworkReason() {
    return  $("#ReasonName");
  }
 
   submitButton() {
     return $('[type="submit"]');
   }
 
   async selectRouteDropdown(routeCard: string) {
    await (await this.routeDropdown).click();
    await (await this.routeDropdown).setValue(routeCard);
     const suggestionOption = await $(`//*[text()="${routeCard}"]`);
     await suggestionOption.waitForDisplayed({timeout:2000})
     await suggestionOption.waitForClickable({timeout:2000})
     console.log(suggestionOption)
     await suggestionOption.click();
   }
 
 
   async selectEquipmentDropdown(equipment: string) {
     await (await this.EquipmentDropDown).click();
     const suggestionOption = await browser.$(`//*[text()="${equipment}"]`);
     await suggestionOption.click();
   }
   
   async selectReworkReason(reason: string) {
     await (await this.ReworkReason).click();
   //  console.log(toStep);
     const suggestionOption = await browser.$(`//*[text()="${reason}"]`);
     await suggestionOption.waitForDisplayed({timeout:2000})
     await suggestionOption.waitForClickable({timeout:2000})
     console.log(suggestionOption)
      await suggestionOption.click();
   }
   async selectToReworkStepDropdown(reworkStep: string) {
    await (await this.ToReworkStep).click();
    const suggestionOption = await browser.$(`//*[text()="${reworkStep}"]`);
    await suggestionOption.waitForDisplayed({timeout:2000})
    await suggestionOption.waitForClickable({timeout:2000})
    console.log(suggestionOption)
     await suggestionOption.click();
  }
   async clickSubmitButton() {
     await this.submitButton().click();
   }
 
   async getAlert() {
     const messageXPath = "//*[contains(text(), 'moved to rework step')]";
     return await $(messageXPath);
   }
 
    get getProductText(){
     return  $('//h4[text()="Product:"]');
   }
 }
 export default new  Rework();
 