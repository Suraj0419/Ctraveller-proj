class DataCollection {
    get routeDropdown() {
     return  $('//input[@id="routeCard"]');
   }

   get IssueQtyDropdown() {
    return  $('#IssueDifferenceReasonId');
  }
 
   submitButton() {
     return $("//button[text()='Submit']");
   }
   

  async getComments() {
    return await $("#Comments");
  }
  async getRouteCard() {
    return await $("#ComponentRouteCard");
  }

  async getIssueQty() {
    return await $("#IssueQty");
  }

  async getDivAccordion(){
    return await $("//div[text()='Additional fields']");
  }

  async enterCommentValue(comments:string){
  
    await (await this.getComments()).setValue(comments);
  }
  async enterComponentRouteCardValue(comments:string){
  
    await (await this.getRouteCard()).setValue(comments);
  }
  async enterIssueQty(comments:string){
  
    await (await this.getIssueQty()).setValue(comments);
  }
  
   async selectRouteDropdown(routeCard: string) {
    await (await this.routeDropdown).click();
    await (await this.routeDropdown).setValue(routeCard);
     const suggestionOption = await $(`//*[text()="${routeCard}"]`);
     await suggestionOption.waitForDisplayed({timeout:2000})
     await suggestionOption.waitForClickable({timeout:2000})
     console.log(suggestionOption)
     await suggestionOption.click();
   }

   
  async selectIssueQtyDropdown(issueQty: string) {
    await (await this.IssueQtyDropdown).click();
    const suggestionOption = await browser.$(`//*[text()="${issueQty}"]`);
    await suggestionOption.click();
  }


   async clickSubmitButton() {
     await this.submitButton().click();
   }

   async getAlert() {
    const messageXPath = "//*[contains(text(),'Data Collected successfully')]";
    return await $(messageXPath);
  }

    get getProductText(){
     return  $('//h4[text()="Product:"]');
   }
 }
 export default new DataCollection();
 