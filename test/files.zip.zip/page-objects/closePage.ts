class closeTransaction {
  get routeDropdown() {
    return $('//input[@id="routeCard"]');
  }

  async selectRouteDropdown(routeCard: string) {
    await (await this.routeDropdown).click();
    await (await this.routeDropdown).setValue(routeCard);
    const suggestionOption = await $(`//*[text()="${routeCard}"]`);
    await suggestionOption.waitForDisplayed({ timeout: 2000 })
    await suggestionOption.waitForClickable({ timeout: 2000 })
    console.log(suggestionOption)
    await suggestionOption.click();
  }

  async getAlert() {
    const messageXPath = "//*[contains(text(), 'Closed successfully')]";
    return await $(messageXPath);
  }

  submitButton() {
    return $('[type="submit"]');
  }

  get getProductText(){
    return  $('//h4[text()="Product:"]');
  }


  async clickSubmitButton() {
    await this.submitButton().click();
  }
}

export default new closeTransaction();