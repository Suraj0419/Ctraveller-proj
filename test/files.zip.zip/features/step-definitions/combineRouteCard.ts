import { Given, Then, When } from "@wdio/cucumber-framework";

import menuPage from "../../page-objects/menuPage.ts";
import { AssertionError, expect } from "chai";
import CombineRouteTransaction from "../../page-objects/combineRoutePage.ts";

Given(/^Go to Combine RouteCard Transaction screen.$/, async function () {
  try {
    await menuPage.MenuButton.click();
    await (await menuPage.transactionMenuItem()).click();
    await (await menuPage.combineRouteCardTransaction()).click();
  } catch (err) {
    throw new AssertionError(`Something Wrong Happened ${err.message}`);
    console.log(err);
  }
});

//Scan the <Route> for details in the Release Screen.

When(
  /^Scan the (.*) for details in the Combine RouteCard Transaction screen.$/,
  async function (route: string) {
    try {
      await CombineRouteTransaction.selectRouteDropdown(route);
      await (await CombineRouteTransaction.getProductText).click();
    
    } catch (err) {
      console.log(`Your error message is ${err}`);
      throw new AssertionError(`Something Wrong Happened ${err.message}`);
    }
  }
);

When(
  /^Click on the checkbox to Combine multiple (.*).$/,
  async function (routes: string) {
    // browser.debug();
    try {
      console.log(routes);
      browser.pause(2000);
      let routeArr = routes.split(",");
      //await browser.debug();
      for (let i = 0; i < routeArr.length; i++) {
        await CombineRouteTransaction.getCheckbox(routeArr[i]);
      }
    } catch (err) {
      throw new AssertionError(`Submit failed ${err.message}`);
    }
  }
);

When(
  /^Click on the submit button in the Combine RouteCard Transaction screen.$/,
  async function () {
    // browser.debug();
    try {
      await CombineRouteTransaction.clickSubmitButton();

      // await browser.debug();
    } catch (err) {
      throw new AssertionError(`Submit failed ${err.message}`);
    }
  }
);

// Click on the submit button in the Associate Transaction.

Then(
  /^"Combined successfully" should confirm the Combine RouteCard Transaction.$/,
  async function () {
    try {
      const expectedResult = await (
        await CombineRouteTransaction.getAlert()
      ).getText();
      expect(expectedResult).includes("Combined successfully");
    } catch (err) {
      console.log(`Your error message is ${err}`);
      throw new AssertionError(`Transaction Failed ${err.message}`);
    }
  }
);
