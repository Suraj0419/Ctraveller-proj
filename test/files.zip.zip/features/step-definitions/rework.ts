import {  Given, Then, When } from "@wdio/cucumber-framework";
import menuPage from "../../page-objects/menuPage.ts";
import { AssertionError, expect } from "chai";
import ReworkTransaction from "../../page-objects/reworkPage.ts";



Given(/^Go to Rework Transaction screen.$/, async function () {
  try {
    await menuPage.MenuButton.click();
    await (await menuPage.transactionMenuItem()).click();
    await (await menuPage.reworkTransaction()).click();
  } catch (err) {
    console.log(err);
  }
});

When(
  /^Scan the route (.*) for rework transaction screen.$/,
  async function (route: string) {
    try {
      await ReworkTransaction.selectRouteDropdown(route);
      await (await ReworkTransaction.getProductText).click();
      // Retrieve the value of the input field
    } catch (err) {
      console.log(`Your error message is ${err}`);
      throw new AssertionError(
        `Workflow is not in the first step of the workflow ${err.message}`
      );
    }
  }
);

When(/^Click on the (.*) in rework transaction screen.$/, async function (equipment: string) {
  // browser.debug();
  try {
    await ReworkTransaction.selectEquipmentDropdown(equipment);
  } catch (err) {
    throw new AssertionError(`Equipment select failed ${err.message}`);
  }
});
When(/^Click on the (.*) in the rework screen.$/, async function (ReworkReason: string) {
    // browser.debug();
    try {
      await ReworkTransaction.selectReworkReason(ReworkReason);
    } catch (err) {
      throw new AssertionError(` ProcessWorkflow select failed ${err.message}`);
    }
  });

  When(/^Select the (.*) in the rework screen.$/, async function (toStep: string) {
    // browser.debug();
    try {
      await ReworkTransaction.selectToReworkStepDropdown(toStep);
    } catch (err) {
      throw new AssertionError(`Equipment select failed ${err.message}`);
    }
  });
When(/^Click on submit button in the rework screen.$/, async function () {
  // browser.debug();
  try {
    await ReworkTransaction.clickSubmitButton();
  } catch (err) {
    console.log(err);
    throw new AssertionError(`Something failed ${err.message}`);
  }
});

Then(
  /^"moved to rework step" should confirm the rework transaction.$/,
  async function () {
    try {
      const expectedResult = await (
        await ReworkTransaction.getAlert()
      ).getText();
      expect(expectedResult).includes('moved to rework step');
    } catch (err) {
      console.log(`Your error message is ${err}`);
      throw new AssertionError(`Transaction Failed ${err.message}`);
    }
  }
);
