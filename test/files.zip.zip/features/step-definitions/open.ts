import {  Given, Then, When } from "@wdio/cucumber-framework";

import menuPage from "../../page-objects/menuPage.ts";
import { AssertionError, expect } from "chai";
import OpenTransaction from "../../page-objects/openPage.ts";



Given(/^Go to Open Transaction screen.$/, async function () {
  try {
    await menuPage.MenuButton.click();
    await (await menuPage.transactionMenuItem()).click();
    await (await menuPage.openTransaction()).click();
  } catch (err) {
    console.log(err);
  }
});

//Scan the <Route> for details in the Release Screen.

When(/^Scan the closed (.*) in the open screen.$/, async function (route: string) {
  try {
    await OpenTransaction.selectRouteDropdown(route);
    await (await OpenTransaction.getProductText).click();
  } catch (err) {
    console.log(`Your error message is ${err}`);
    throw new AssertionError(`Something Wrong Happened ${err.message}`);
  }
});

When(/^In the open screen click on the submit button.$/, async function () {
  // browser.debug();
  try {
    await OpenTransaction.clickSubmitButton();
  } catch (err) {
    throw new AssertionError(`Submit failed ${err.message}`);
  }
});

Then(
  /^"Opened successfully" should confirm the open transaction.$/,
  async function () {
    try {
      const expectedResult = await (await OpenTransaction.getAlert()).getText();
      expect(expectedResult).includes("Opened successfully");
    } catch (err) {
      console.log(`Your error message is ${err}`);
      throw new AssertionError(`Transaction Failed ${err.message}`);
    }
  }
);
