import { Given, Then, When } from "@wdio/cucumber-framework";
import menuPage from "../../page-objects/menuPage.ts";
import RouteCardTransaction from "../../page-objects/routeMaintenanceTransactionPage.ts";
import { AssertionError, expect } from "chai";

Given(
  /^Navigate to the RouteCard Maintenance Transaction screen.$/,
  async function () {
    try {
      await(await menuPage.MenuButton).click();
     await (await menuPage.transactionMenuItem()).click();
      await(await menuPage.routeCardMaintenanceTransaction()).click();
    } catch (err) {
      console.log(err);
    }
  }
);

Then(
  /^Scan the (.*) for details in the Maintenance Transaction screen.$/,
  async function (route: string) {
    try {
      await RouteCardTransaction.selectRouteDropdown(route);
      await (await RouteCardTransaction.getProductText).click();
    } catch (err) {
      console.log(`Your error message is ${err}`);
      throw new AssertionError(`Something Wrong Happened ${err.message}`);
    }
  }
);

When(
  /^Select the Department (.*) field in the Maintenance transaction screen.$/,
  async function (department: string) {
    // browser.debug();
    try {
      await RouteCardTransaction.enterDepartment(department);
    } catch (err) {
      throw new AssertionError(`Hold Reason select failed ${err.message}`);
    }
  }
);


When(
  /^Select the Level (.*) field  in the the Maintenance transaction screen.$/,
  async function (level: string) {
    // browser.debug();
    try {
      await RouteCardTransaction.enterLevel(level);
    } catch (err) {
      throw new AssertionError(`Hold Reason select failed ${err.message}`);
    }
  }
);
When(
  /^Select the Start Reason (.*) field  in the the Maintenance transaction screen.$/,
  async function (startReason: string) {
    // browser.debug();
    try {
      await RouteCardTransaction.selectStartReason(startReason);
    } catch (err) {
      throw new AssertionError(`Hold Reason select failed ${err.message}`);
    }
  }
);



When(
  /^Select the Production Order (.*) field  in the the Maintenance transaction screen.$/,
  async function (productionOrder: string) {
    // browser.debug();
    try {
      await RouteCardTransaction.selectProductionOrder(productionOrder);
    } catch (err) {
      throw new AssertionError(`Hold Reason select failed ${err.message}`);
    }
  }
);
When(
    /^Select the Factory (.*) field  in the the Maintenance transaction screen.$/,
    async function (factory: string) {
      // browser.debug();
      try {
        await RouteCardTransaction.selectFactoryDropdown(factory);
      } catch (err) {
        throw new AssertionError(`Hold Reason select failed ${err.message}`);
      }
    }
  );

When(
  /^Select the Product (.*) field  in the the Maintenance transaction screen.$/,
  async function (product: string) {
    // browser.debug();
    try {
      await RouteCardTransaction.selectProductDropdown(product);
    } catch (err) {
      throw new AssertionError(`Hold Reason select failed ${err.message}`);
    }
  }
);

When(
    /^Select the UOM (.*) field  in the the Maintenance transaction screen.$/,
    async function (uom: string) {
      // browser.debug();
      try {
        await RouteCardTransaction.selectUOMDropdown(uom);
      } catch (err) {
        throw new AssertionError(`Hold Reason select failed ${err.message}`);
      }
    }
  );

  When(
    /^Select the Duedate (.*) field  in the the Maintenance transaction screen.$/,
    async function (dueDate: string) {
      // browser.debug();
      try {
        await RouteCardTransaction.enterDueDate(dueDate)
      } catch (err) {
        throw new AssertionError(`Hold Reason select failed ${err.message}`);
      }
    }
  );

 

  When(
    /^Select the ExpirationDate (.*) field  in the the Maintenance transaction screen.$/,
    async function (expDate: string) {
      // browser.debug();
      try {
        await RouteCardTransaction.enterExpirationDate(expDate)
      } catch (err) {
        throw new AssertionError(`Hold Reason select failed ${err.message}`);
      }
    }
  );

  When(/^Click on the submit button in Route Maintenance Transaction screen.$/, async function () {
    await RouteCardTransaction.clickSubmitButton();
});
  Then(/^"RouteCard Maintenance successful" message should  confirming the route maintenance transaction.$/, async function () {
    try {
       const expectedResult=await (await RouteCardTransaction.getAlert()).getText();
      expect(expectedResult).includes("RouteCard Maintenance successful");
    } catch (err) {
      console.log(`Your error message is ${err}`);
      throw new AssertionError(`Transaction Failed ${err.message}`);
    }
  });

