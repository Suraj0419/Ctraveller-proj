import { Given, Then, When } from "@wdio/cucumber-framework";

import menuPage from "../../page-objects/menuPage.ts";
import { AssertionError, expect } from "chai";
import DataCollection from "../../page-objects/dataCollectionPage.ts";

Given(/^Go to Data Collection Transaction screen.$/, async function () {
  try {
    await menuPage.MenuButton.click();
    await (await menuPage.transactionMenuItem()).click();
    await (await menuPage.dataCollectionTransaction()).click();
  } catch (err) {
    throw new AssertionError(`Something Wrong Happened ${err.message}`);
    console.log(err);
  }
});

//Scan the <Route> for details in the Release Screen.

When(
  /^Scan the (.*) for Data Collection details in the screen.$/,
  async function (route: string) {
    try {
      await DataCollection.selectRouteDropdown(route);
      await (await DataCollection.getProductText).click();
    
    } catch (err) {
      console.log(`Your error message is ${err}`);
      throw new AssertionError(`Something Wrong Happened ${err.message}`);
    }
  }
);

When(
  /^Enter the (.*) in Length input field.$/,
  async function (length: string) {
    // browser.debug();
    try {
    await DataCollection.enterLength(length);
    } catch (err) {
      throw new AssertionError(`Submit failed ${err.message}`);
    }
  }
);

When(
    /^Enter the (.*) in Breadth input field.$/,
    async function (breadth: string) {
      // browser.debug();
      try {
      await DataCollection.enterBreadth(breadth);
      } catch (err) {
        throw new AssertionError(`Submit failed ${err.message}`);
      }
    }
  );

  When(
    /^Enter the (.*) in Height input field.$/,
    async function (height: string) {
      // browser.debug();
      try {
      await DataCollection.enterHeight(height);
      } catch (err) {
        throw new AssertionError(`Submit failed ${err.message}`);
      }
    }
  );


  When(
    /^Click on the isValid checkbox  in Data Collection screen.$/,
    async function () {
      // browser.debug();
      try {
      await DataCollection.clickCheckbox();
      } catch (err) {
        throw new AssertionError(`Submit failed ${err.message}`);
      }
    }
  );

  When(
    /^Click on submit button in the Data Collection screen.$/,
    async function () {
      // browser.debug();
      try {
        await DataCollection.clickSubmitButton();
  
        // await browser.debug();
      } catch (err) {
        throw new AssertionError(`Submit failed ${err.message}`);
      }
    }
  );

  When(
    /^Enter (.*) in the data collection screen.$/,
    async function (comment: string) {
      // browser.debug();
      try {
      await DataCollection.enterComments(comment);
      } catch (err) {
        throw new AssertionError(`Submit failed ${err.message}`);
      }
    }
  );






// Click on the submit button in the Associate Transaction.

Then(
  /^"Data Collected successfully" should confirm the Data Collection transaction.$/,
  async function () {
    try {
      const expectedResult = await (
        await DataCollection.getAlert()
      ).getText();
      expect(expectedResult).includes("Data Collected successfully");
    } catch (err) {
      console.log(`Your error message is ${err}`);
      throw new AssertionError(`Transaction Failed ${err.message}`);
    }
  }
);
