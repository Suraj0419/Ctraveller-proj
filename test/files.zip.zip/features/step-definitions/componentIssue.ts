import { Given, Then, When } from "@wdio/cucumber-framework";

import menuPage from "../../page-objects/menuPage.ts";
import { AssertionError, expect } from "chai";
import ComponentIssueTransaction from "../../page-objects/componentIssuePage.ts";

Given(/^Go to Component Issue screen.$/, async function () {
  try {
    await menuPage.MenuButton.click();
    await (await menuPage.transactionMenuItem()).click();
    await (await menuPage.dataCollectionTransaction()).click();
  } catch (err) {
    throw new AssertionError(`Something Wrong Happened ${err.message}`);
    console.log(err);
  }
});

//Scan the <Route> for details in the Release Screen.

When(
  /^Scan the (.*) for details in Component Issue screen.$/,
  async function (route: string) {
    try {
      await ComponentIssueTransaction.selectRouteDropdown(route);
      await (await ComponentIssueTransaction.getProductText).click();
    } catch (err) {
      console.log(`Your error message is ${err}`);
      throw new AssertionError(`Something Wrong Happened ${err.message}`);
    }
  }
);

When(
  /^Enter the Component RouteCard (.*) input in the Component Issue screen.$/,
  async function (componentRouteCard: string) {
    // browser.debug();
    try {
      await ComponentIssueTransaction.enterComponentRouteCardValue(
        componentRouteCard
      );
    } catch (err) {
      throw new AssertionError(`Submit failed ${err.message}`);
    }
  }
);

When(/^Enter the Issue Qty (.*).$/, async function (issueQty: string) {
  // browser.debug();
  try {
    await ComponentIssueTransaction.enterIssueQty(issueQty);
  } catch (err) {
    throw new AssertionError(`Submit failed ${err.message}`);
  }
});

When(
  /^Click on submit button in the Component Issue screen.$/,
  async function () {
    // browser.debug();
    try {
      await ComponentIssueTransaction.clickSubmitButton();

      // await browser.debug();
    } catch (err) {
      throw new AssertionError(`Submit failed ${err.message}`);
    }
  }
);

Then(
  /^"Data Collected successfully" should confirm the Data Collection transaction.$/,
  async function () {
    try {
      const expectedResult = await (
        await ComponentIssueTransaction.getAlert()
      ).getText();
      expect(expectedResult).includes("Data Collected successfully");
    } catch (err) {
      console.log(`Your error message is ${err}`);
      throw new AssertionError(`Transaction Failed ${err.message}`);
    }
  }
);
