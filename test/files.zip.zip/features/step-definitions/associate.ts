import { Given, Then, When } from "@wdio/cucumber-framework";

import menuPage from "../../page-objects/menuPage.ts";
import { AssertionError, expect } from "chai";
import AssociateTransaction from "../../page-objects/associatePage.ts";

Given(/^Go to the Disassociate transaction screen.$/, async function () {
  try {
    await menuPage.MenuButton.click();
    await (await menuPage.transactionMenuItem()).click();
    await (await menuPage.associateTransaction()).click();
  } catch (err) {
    throw new AssertionError(`Something Wrong Happened ${err.message}`);
    console.log(err);
  }
});

//Scan the <Route> for details in the Release Screen.

When(
  /^Scan the (.*) for details in the Associate Transaction.$/,
  async function (route: string) {
    try {
      await AssociateTransaction.selectRouteDropdown(route);
      await (await AssociateTransaction.getProductText).click();
    
    } catch (err) {
      console.log(`Your error message is ${err}`);
      throw new AssertionError(`Something Wrong Happened ${err.message}`);
    }
  }
);

When(
  /^Click on the checkbox for the multiple elgible (.*).$/,
  async function (routes: string) {
    // browser.debug();
    try {
      console.log(routes);
      browser.pause(2000);
      let routeArr = routes.split(",");
      //await browser.debug();
      for (let i = 0; i < routeArr.length; i++) {
        await AssociateTransaction.getCheckbox(routeArr[i]);
      }
    } catch (err) {
      throw new AssertionError(`Submit failed ${err.message}`);
    }
  }
);

When(
  /^Click on the submit button in the Associate Transaction.$/,
  async function () {
    // browser.debug();
    try {
      await AssociateTransaction.clickSubmitButton();

      // await browser.debug();
    } catch (err) {
      throw new AssertionError(`Submit failed ${err.message}`);
    }
  }
);

// Click on the submit button in the Associate Transaction.

Then(
  /^"Associated successfully" should confirm the Associate transaction.$/,
  async function () {
    try {
      const expectedResult = await (
        await AssociateTransaction.getAlert()
      ).getText();
      expect(expectedResult).includes("Associated successfully");
    } catch (err) {
      console.log(`Your error message is ${err}`);
      throw new AssertionError(`Transaction Failed ${err.message}`);
    }
  }
);
